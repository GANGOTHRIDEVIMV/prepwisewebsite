const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { protect } = require('../middleware/auth');
const router  = express.Router();

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    const dir = path.join(__dirname, '../uploads/resumes');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `resume_${req.user._id}_${Date.now()}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['.pdf', '.doc', '.docx', '.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowed.includes(ext)) return cb(new Error('Only PDF, DOC, DOCX, TXT files allowed'));
    cb(null, true);
  }
});

// ── POST /api/resume/upload ───────────────────
router.post('/upload', protect, upload.single('resume'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded.' });

    const fileUrl  = `/uploads/resumes/${req.file.filename}`;
    const fileText = extractTextFromFile(req.file.path, req.file.originalname);
    const analysis = analyzeResume(fileText);

    // Store resume info on user
    const User = require('../models/User');
    await User.findByIdAndUpdate(req.user._id, {
      resumeUrl:  fileUrl,
      resumeText: fileText.substring(0, 5000),
      resumeData: analysis
    });

    res.json({
      success: true,
      fileUrl,
      analysis,
      message: 'Resume uploaded and analysed successfully!'
    });
  } catch (err) {
    console.error('resume upload:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── GET /api/resume/questions ─────────────────
// Generate interview questions from stored resume
router.get('/questions', protect, async (req, res) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user._id);

    if (!user.resumeData) {
      return res.status(400).json({ success: false, message: 'No resume uploaded yet. Please upload your resume first.' });
    }

    const questions = generateResumeQuestions(user.resumeData, user.resumeText || '');

    res.json({ success: true, questions, resumeData: user.resumeData });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ── GET /api/resume/info ──────────────────────
router.get('/info', protect, async (req, res) => {
  try {
    const User = require('../models/User');
    const user = await User.findById(req.user._id).select('resumeUrl resumeData resumeText');
    if (!user.resumeUrl) return res.json({ success: false, message: 'No resume uploaded.' });
    res.json({ success: true, resumeUrl: user.resumeUrl, resumeData: user.resumeData });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function extractTextFromFile(filePath, originalName) {
  try {
    const ext = path.extname(originalName).toLowerCase();
    if (ext === '.txt') {
      return fs.readFileSync(filePath, 'utf8');
    }
    // For PDF/DOC we read as text buffer — basic extraction
    const buf = fs.readFileSync(filePath);
    // Strip binary, get readable text
    const raw = buf.toString('latin1').replace(/[^\x20-\x7E\n\r\t]/g, ' ').replace(/\s+/g, ' ');
    return raw.substring(0, 8000);
  } catch {
    return '';
  }
}

function analyzeResume(text) {
  const lower = text.toLowerCase();

  // Detect skills
  const techSkills = ['javascript','python','java','react','node','sql','mongodb','aws','docker','kubernetes',
    'typescript','angular','vue','c++','c#','golang','rust','swift','kotlin','flutter',
    'machine learning','deep learning','tensorflow','pytorch','pandas','numpy','git','linux','agile','scrum'];
  const foundSkills = techSkills.filter(s => lower.includes(s));

  // Detect experience keywords
  const expPatterns = lower.match(/(\d+)\s*(?:\+)?\s*years?\s+(?:of\s+)?(?:experience|exp)/i);
  const yearsExp    = expPatterns ? parseInt(expPatterns[1]) : null;

  // Detect sections
  const hasEducation   = /education|university|college|degree|bachelor|master|phd/i.test(text);
  const hasExperience  = /experience|work history|employment|worked at|company/i.test(text);
  const hasProjects    = /project|built|developed|created|implemented/i.test(text);
  const hasCertificates= /certif|credential|aws certified|google certified/i.test(text);

  // Detect role hints
  let detectedRole = 'software-engineer';
  if (/product manager|product management|pm\s/i.test(text)) detectedRole = 'product-manager';
  else if (/data scientist|data science|machine learning engineer/i.test(text)) detectedRole = 'data-scientist';
  else if (/ux designer|ui designer|product designer/i.test(text)) detectedRole = 'designer';
  else if (/marketing|growth|seo|content strategy/i.test(text)) detectedRole = 'marketing';

  // Extract name (first non-empty line usually)
  const lines       = text.split(/[\n\r]+/).map(l => l.trim()).filter(Boolean);
  const candidateName = lines[0] && lines[0].length < 60 ? lines[0] : '';

  return {
    candidateName,
    detectedRole,
    foundSkills,
    yearsExp,
    hasEducation,
    hasExperience,
    hasProjects,
    hasCertificates,
    wordCount: text.split(/\s+/).length,
    score: Math.min(100, 40 +
      (foundSkills.length * 3) +
      (hasEducation ? 10 : 0) +
      (hasExperience ? 15 : 0) +
      (hasProjects ? 10 : 0) +
      (hasCertificates ? 8 : 0)
    )
  };
}

function generateResumeQuestions(data, text) {
  const questions = [];
  const { detectedRole, foundSkills, hasProjects, hasExperience, yearsExp } = data;

  // Universal opening
  questions.push('Walk me through your resume. Tell me about yourself and what brought you to apply for this role.');

  // Skills-based questions
  if (foundSkills.length > 0) {
    const sk = foundSkills.slice(0, 3);
    questions.push(`Your resume mentions ${sk.join(', ')}. Can you walk me through a project where you used these skills together?`);
    questions.push(`How proficient are you in ${sk[0]}? Describe the most complex thing you have built with it.`);
  }

  // Project questions
  if (hasProjects) {
    questions.push('Tell me about the most impactful project on your resume. What was your specific role, the challenges you faced, and the outcome?');
    questions.push('Walk me through a project that did not go as planned. What happened and what did you learn?');
  }

  // Experience questions
  if (hasExperience) {
    questions.push('Describe a situation from your work history where you had to make a tough decision with limited information. What did you do?');
    if (yearsExp && yearsExp >= 2) {
      questions.push(`With ${yearsExp}+ years of experience, what is the biggest professional lesson you have learned?`);
    }
  }

  // Role-specific
  if (detectedRole === 'software-engineer') {
    questions.push('How do you approach debugging a production issue at 2 AM? Walk me through your process.');
    questions.push('How do you ensure the code you write is maintainable and understandable by others?');
  } else if (detectedRole === 'product-manager') {
    questions.push('Based on your resume, how have you handled conflicting priorities between engineering and business stakeholders?');
  } else if (detectedRole === 'data-scientist') {
    questions.push('Describe a data project where your model or analysis directly changed a business decision.');
  }

  // Behavioural always included
  questions.push('What is your greatest professional achievement, and how did you accomplish it?');
  questions.push('Where do you see yourself in 3 years, and how does this role fit into that plan?');

  return questions.slice(0, 7);
}

module.exports = router;
